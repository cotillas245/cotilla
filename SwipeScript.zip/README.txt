First Time Setup for SwipeScripts

Files inside SwipeScript.zip
    SwipeScripts.exe
        When you run SwipeScripts.exe for the first time in a folder, it will create the necessary configuration files.
    doNotRun.exe
        Just don't run it. It will open by itself when needed.
    Readme.txt
        Hey! :)

Files Created:

    Settings.json:
        {
            "license_key": "REQUIRED",
            "discWebhook": "optional",
            "apiKeys": {
                "capmonsterAPI": "",
                "2captchaAPI": "",
                "capsolverAPI": ""
            },
            "Imap": {
                "gmail": {
                    "username": "your_email@gmail.com",
                    "appPassword": "your_app_password"
                },
                "outlook": {
                    "username": "your_email@outlook.com",
                    "appPassword": "your_app_password"
                },
                "icloud": {
                    "username": "",
                    "appPassword": ""
                }
            }
        }
 
        License Key: REQUIRED
        Discord Webhook: Optional
        API Keys: Optional
        capmonsterAPI: capmonster
        2captchaAPI: 2captcha
        capsolverAPI: capsolver
        IMAP Settings: Optional
        gmail: IMAP settings for Gmail
        outlook: IMAP settings for Outlook
        icloud: Coming soon, leave empty

    Mails.csv:
        Add the emails for entries on the different modules.

    proxy.txt: 
        REQUIRED
        Add your proxy list in the format: ip:port:username:password

    links.csv: 
        Leave empty.
        When running the mail scraper, links scraped from the mail will be stored here.
        Validating option will take the links from here and validate them.

Steps to Follow:
    Run SwipeScripts.exe:
        This will generate the necessary files listed above in the folder where the executable is located.

    Edit Settings.json:
        Fill in the required fields (license_key) and any optional fields as needed.

    Add Proxies:
        Open proxy.txt and add your proxy details.

    Prepare Email List:
        Open Mails.csv and add the email addresses you want to use.

    Use the Application:
        Now, you can run the application and use its features as intended.